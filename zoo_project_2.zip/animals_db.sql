-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 31, 2024 at 07:57 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `animals_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `animaux`
--

DROP TABLE IF EXISTS `animaux`;
CREATE TABLE IF NOT EXISTS `animaux` (
  `animal_id` int NOT NULL AUTO_INCREMENT,
  `prenom` varchar(255) DEFAULT NULL,
  `espece` varchar(255) DEFAULT NULL,
  `regime` varchar(255) DEFAULT NULL,
  `date_arrive` varchar(255) DEFAULT NULL,
  `pays_origine` varchar(255) DEFAULT NULL,
  `enclos_id` int NOT NULL,
  PRIMARY KEY (`animal_id`),
  KEY `fk_animaux_enclos_idx` (`enclos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `animaux`
--

INSERT INTO `animaux` (`animal_id`, `prenom`, `espece`, `regime`, `date_arrive`, `pays_origine`, `enclos_id`) VALUES
(3, 'Max', 'Pingouin', 'Carnivore', '2024-05-15', 'Groenland', 3),
(4, 'Gerald', 'Lion', 'Carnivore', '2024-04-24', 'République du Congo', 1),
(5, 'Lisa', 'Lion', 'Carnivore', '2024-03-08', 'Zimbabwe', 1);

-- --------------------------------------------------------

--
-- Table structure for table `enclos`
--

DROP TABLE IF EXISTS `enclos`;
CREATE TABLE IF NOT EXISTS `enclos` (
  `enclos_id` int NOT NULL AUTO_INCREMENT,
  `zone` varchar(30) DEFAULT NULL,
  `environnement` varchar(50) DEFAULT NULL,
  `taille` varchar(20) DEFAULT NULL,
  `amenagements` mediumtext,
  `capacite` int DEFAULT NULL,
  PRIMARY KEY (`enclos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `enclos`
--

INSERT INTO `enclos` (`enclos_id`, `zone`, `environnement`, `taille`, `amenagements`, `capacite`) VALUES
(1, 'Afrique', 'Jungle', 'Grand', 'Décoration pour faire des parcours', 8),
(2, 'Europe', 'Terrain vert plat', 'Petit', 'Une hutte pour dormir le soir', 3),
(3, 'Australie', 'Savane', 'Moyen', 'Herbe fraîche au cas ou', 5);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `animaux`
--
ALTER TABLE `animaux`
  ADD CONSTRAINT `fk_animaux_enclos` FOREIGN KEY (`enclos_id`) REFERENCES `enclos` (`enclos_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
