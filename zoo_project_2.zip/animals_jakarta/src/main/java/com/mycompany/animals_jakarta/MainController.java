package com.mycompany.animals_jakarta;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("") //GetMapping va prendre la requete pour le contexte (ici l'url) de la page home
    public String showHomePage() {
        System.out.println("Home page");
        return "index"; //index ici est le nom de notre vue (page)
    }
}
