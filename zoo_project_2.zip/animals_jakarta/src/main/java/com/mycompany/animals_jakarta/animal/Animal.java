package com.mycompany.animals_jakarta.animal;
//Notre entité animal !

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "animaux")
public class Animal {
    @Id //Veux dire "ce champ correspond à la clé primaire)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "animal_id") //Les valeurs de la colonne "Id" vont être automatiquement générés par la database
    private Integer animal_id;

    @Column(name = "prenom")
    private String prenom;

    @Column(name = "espece")
    private String espece;

    @Column(name = "regime")
    private String regime;

    @Column(name = "date_arrive")
    private String date_arrive;

    @Column(name = "pays_origine")
    private String pays_origine;

    @Column(name = "enclos_id")
    private Integer enclos_id;

    public Integer getAnimal_id() {
        return animal_id;
    }

    public void setAnimal_id(Integer animal_id) {
        this.animal_id = animal_id;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEspece() {
        return espece;
    }

    public void setEspece(String espece) {
        this.espece = espece;
    }

    public String getRegime() {
        return regime;
    }

    public void setRegime(String regime) {
        this.regime = regime;
    }

    public String getDate_arrive() {
        return date_arrive;
    }

    public void setDate_arrive(String date_arrive) {
        this.date_arrive = date_arrive;
    }

    public String getPays_origine() {
        return pays_origine;
    }

    public void setPays_origine(String pays_origine) {
        this.pays_origine = pays_origine;
    }

    public Integer getEnclos_id() {
        return enclos_id;
    }

    public void setEnclos_id(Integer enclos_id) {
        this.enclos_id = enclos_id;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "animal_id=" + animal_id +
                ", prenom='" + prenom + '\'' +
                ", espece='" + espece + '\'' +
                ", regime='" + regime + '\'' +
                ", date_arrive='" + date_arrive + '\'' +
                ", pays_origine='" + pays_origine + '\'' +
                ", enclos_id='" + enclos_id + '\'' +
                '}';
    }
}
