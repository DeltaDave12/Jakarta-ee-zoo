package com.mycompany.animals_jakarta.animal;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.text.SimpleDateFormat;
import java.util.List;

@Controller
public class AnimalController {
    @Autowired private AnimalService service; //Instance de UserService

    @GetMapping("/animals") //Méthode pour ce lien, @GetMapping permet de faire des requetes REST HTTP
    public String showAnimals(Model model)  { //Model spring mvc
        List<Animal> listAnimals = service.listAll();
        model.addAttribute("listAnimals", listAnimals);
        return "animals";
    }

    @GetMapping("/animals/new")
    public String showNewAnimalForm(Model model) {
        model.addAttribute("animal", new Animal()); //Donne accès à User pour la page
        model.addAttribute("pageTitle", "Ajouter Nouvel Animal");
        return "animals_form"; //Retourne notre page avec form
    }

    @PostMapping("/animals/save")
    public String saveAnimal(Animal animal, RedirectAttributes ra) { //Notre méthode pour créé un user, on le créé grâce aux champs de notre template du form
        service.save(animal);
        ra.addFlashAttribute("message", "Animal enregistré !");
        return "redirect:/animals"; //retourne la direction pour nous rediriger sur animals
    }

    @GetMapping("/animals/edit/{animal_id}")
    public String showEditForm(@PathVariable("animal_id") Integer animal_id, Model model, RedirectAttributes ra) { //Montre le form pour le user détenant l'id
        try {
            Animal animal = service.get(animal_id);
            model.addAttribute("animal", animal);
            model.addAttribute("pageTitle", "Modifier Animal (ID: " + animal_id + ")");
            return "animals_form";
        } catch (AnimalNotFoundException e) {
            ra.addFlashAttribute("message", "Animal modifié avec succès !");
            return "redirect:/animals";
        }
    }

    @GetMapping("/animals/delete/{animal_id}")
    public String deleteAnimal(@PathVariable("animal_id") Integer animal_id, RedirectAttributes ra) { //Montre le form pour le user détenant l'id
        try {
            service.delete(animal_id);
            ra.addFlashAttribute("message", "Animal with id " + animal_id + " supprimé !");
        } catch (AnimalNotFoundException e) {
            ra.addFlashAttribute("message", e.getMessage()); //On renvoir le message de l'exception
        }
        return "redirect:/animals";
    }
}
