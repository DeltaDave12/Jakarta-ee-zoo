package com.mycompany.animals_jakarta.animal;

public class AnimalNotFoundException extends Throwable {
    public AnimalNotFoundException(String message) {
        super(message);
    }
}
