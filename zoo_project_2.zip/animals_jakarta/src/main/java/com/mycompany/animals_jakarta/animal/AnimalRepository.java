package com.mycompany.animals_jakarta.animal;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

//Notre classe pour Animal
//Extends CrudRepository<NotreClasse, TypeDeLaClePrimaire>. CrudRepository propose des methodes de base facilitant la logique Crud pour notre Animal.
@Repository
public interface AnimalRepository extends CrudRepository<Animal, Integer> {
    @Query("SELECT COUNT(a) FROM Animal a WHERE a.animal_id = :animal_id")
    Long countByAnimalId(@Param("animal_id") Integer animal_id);
}
