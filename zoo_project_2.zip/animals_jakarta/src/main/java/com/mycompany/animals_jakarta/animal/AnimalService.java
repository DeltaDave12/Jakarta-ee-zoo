package com.mycompany.animals_jakarta.animal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class AnimalService {
    @Autowired private AnimalRepository repo; //Référence au repository Animal

    public List<Animal> listAll() {
        return (List<Animal>) repo.findAll(); //findAll() retourne des iterables donc (List<User>) obligé
    }

    public void save(Animal animal) {
        repo.save(animal);
    }

    public Animal get(Integer animal_id) throws AnimalNotFoundException { //Methode qui retournera notre objet User grâce à l'ID
        Optional<Animal> result = repo.findById(animal_id);
        if (result.isPresent()) { //On check si le resultat existe
            return result.get();
        }
        throw new AnimalNotFoundException("Pas d'animal trouvé avec l'ID " + animal_id);
    }

    public void delete(Integer animal_id) throws AnimalNotFoundException {//Methode pour supprimer le user avec l'id
        Long count = repo.countByAnimalId(animal_id);
        if (count == null || count == 0) {
            throw new AnimalNotFoundException("Aucun animal trouvé avec un ID " + animal_id);
        }
        repo.deleteById(animal_id);
    }
}
