package com.mycompany.animals_jakarta;
//Fichier pour faire des tests unitaires sur UserRepository

import com.mycompany.animals_jakarta.animal.Animal;
import com.mycompany.animals_jakarta.animal.AnimalRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import java.util.Optional;

import java.util.Optional;

@DataJpaTest //Annotation pour utiliser JPA Test
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE) //Lancer les tests sur la vrai database (pas celle en mémoire).
@Rollback(false) //Garder la data dans la database
public class AnimalRepositoryTest {
    @Autowired private AnimalRepository repo;

}
